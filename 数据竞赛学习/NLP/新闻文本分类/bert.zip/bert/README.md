# step 1: create pretraining data
```shell
bash create_pretraining_data.sh
```

# step 2: run pretraining
```shell
bash run_pretraining.sh
```

# step 3: convert checkpoint
```shell
bash run_pretraining.sh
```
